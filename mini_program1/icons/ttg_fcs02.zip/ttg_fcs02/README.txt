Touch The Girl! DLC installer


--- How to install DLC ---

1. Close the game if it's running.
	(The installers don't start while the game is running.)

2. Run "install_**##.exe" (**## - costume set number)

	If installation problems occur,
	please follow the instructions on the screen.

	If you're using a swf stand alone player,
	run "install_**##.swf".


If you have any other problems with installation,
please see the following page.
https://sawatex.x0.com/faq.htm



Sawatex websites
https://sawatex.x0.com
https://www.patreon.com/sawatex